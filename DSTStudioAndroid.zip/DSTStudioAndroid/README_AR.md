# استوديو الرشمات DST — مشروع أندرويد

هذا مشروع Android Studio يحزم واجهة HTML داخل تطبيق Android WebView، ويمكن بناء APK منه.

## بناء APK عبر Android Studio
1. ثبّت Android Studio وJDK 17.
2. افتح مجلد `DSTStudioAndroid`.
3. وافق على تنزيل مكونات Gradle/Android SDK المطلوبة.
4. من القائمة اختر Build > Build APK(s).
5. عادةً يوجد الملف الناتج في `app/build/outputs/apk/debug/app-debug.apk`.

## بناء APK من GitHub Actions
1. أنشئ مستودع GitHub جديدًا وارفع جميع ملفات هذا المشروع إليه.
2. افتح تبويب Actions وفعّل workflows إن طلب ذلك.
3. شغّل `Build Android APK` من Run workflow.
4. عند نجاح البناء نزّل artifact باسم `DSTStudio-debug-apk` وافتحه على جهاز أندرويد.

## ملاحظات
- هذه نسخة debug غير موقّعة للنشر التجاري.
- يتطلب البناء اتصالًا لتنزيل Gradle وAndroid SDK.
- اختبار APK على جهاز فعلي غير ممكن في بيئة إعداد الملفات هذه؛ اختبر استيراد الصور وتصدير DST قبل الإنتاج.
- محرك الغرز في الواجهة تجريبي، ولا يضمن جودة صناعية أو توافقًا مع كل ماكينة.
